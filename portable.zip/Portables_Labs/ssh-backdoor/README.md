# ssh-backdoor
This is to be used for legal purposes ONLY.
Only use this on systems that you are allowed to.
